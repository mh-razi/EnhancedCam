// Top-level build file.
// Also create gradle.properties in the project root with:
//   org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8
//   android.useAndroidX=true
//   android.nonTransitiveRClass=true
//   kotlin.code.style=official
plugins {
    id("com.android.application") version "8.5.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
